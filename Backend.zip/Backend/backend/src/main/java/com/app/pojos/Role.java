package com.app.pojos;

public enum Role {
	ADMIN, CUSTOMER, STOREMGR, ORDERMGR
}
